package com.edu.fpoly.bookmanager.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.edu.fpoly.bookmanager.R;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class NguoiDungAdapter extends BaseAdapter {
    List<NguoiDung> list = new ArrayList<>();
    Context context;
    LayoutInflater inflater;
    public NguoiDungAdapter(Context context,List<NguoiDung> list)
    {
        this.context = context;
        this.list = list;
        //goi doi tuong khoi tao layout
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //tinh tong so item
    @Override
    public int getCount() {
        return list.size();
    }
    //lay ve 1 doi tuong item
    @Override
    public Object getItem(int i) {
        return list.get(i);
    }
    //lay ve item id
    @Override
    public long getItemId(int i) {
        return 0;
    }
    //Tao view+ gan du lieu cho view
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //1. Tao view
        ViewHolder holder;
        //1.1. Neu chua tao view => tao view moi, tao thanh template de lan sau su dung
        if(view==null)
        {
            holder = new ViewHolder();//tao doi tuong view moi
            //tao layout cho view
            view = inflater.inflate(R.layout.item_nguoi_dung,null);
            //anh xa tung thanh phan
            holder.img = view.findViewById(R.id.ivIcon);
            holder.tvName = view.findViewById(R.id.tvName);
            holder.tvPhone=view.findViewById(R.id.tvPhone);
            holder.imgDelete = view.findViewById(R.id.ivDelete);
            //tao template
            view.setTag(holder);
        }
        //1.2: neu da co view => ta lay view cu ra su dung
        else
        {
            holder = (ViewHolder)view.getTag();
        }
        //2. gan du lieu cho view
        NguoiDung nd = (NguoiDung)list.get(i);
        holder.tvName.setText(nd.getHoTen());
        holder.tvPhone.setText(nd.getPhone());
        return view;
    }
    public static class ViewHolder{//lop anh xa voi item_nguoi_dung
        ImageView img;
        TextView tvName;
        TextView tvPhone;
        ImageView imgDelete;
    }
}
