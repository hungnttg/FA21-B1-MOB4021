package com.edu.fpoly.bookmanager.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.dao.TheLoaiDAO;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME="db";
    //1.tao database
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);//tao CSDL
    }
    //2.tao cac bang du lieu
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(NguoiDungDAO.SQL_NGUOI_DUNG);
        sqLiteDatabase.execSQL(TheLoaiDAO.SQL_THE_LOAI);

    }
    //3.nang cap cac bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ NguoiDungDAO.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TheLoaiDAO.TABLE_NAME);

    }
}
