package com.edu.fpoly.bookmanager.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edu.fpoly.bookmanager.NguoiDungActivity;
import com.edu.fpoly.bookmanager.R;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.List;

public class NguoiDungAdapterRecycler extends
        RecyclerView.Adapter<NguoiDungAdapterRecycler.RecyclerViewHolder> {
    private Context context;
    private List<NguoiDung> lsNguoiDung;//danh sach nguoi dung
    private LayoutInflater inflater;//doi tuong sinh layout
    private NguoiDungDAO nguoiDungDAO;

    public NguoiDungAdapterRecycler(Context context, List<NguoiDung> lsNguoiDung) {
        this.context = context;
        this.lsNguoiDung = lsNguoiDung;
        nguoiDungDAO = new NguoiDungDAO(context);
        this.inflater=
                (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);//khởi tạo đối tương tạo layout
    }
    //1.ham tao view
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_nguoi_dung,null);//ánh xạ layout với view
        RecyclerViewHolder viewHolder = new RecyclerViewHolder(view);//gắn view vào viewHolder
        //ánh xạ từng thành phần
        viewHolder.ivIcon = view.findViewById(R.id.ivIcon);
        viewHolder.tvName = view.findViewById(R.id.tvName);
        viewHolder.tvPhone = view.findViewById(R.id.tvPhone);
        viewHolder.ivDelete = view.findViewById(R.id.ivDelete);
        //xu ly su kien xoa
        viewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //xu ly xoa
                //b1 - xoa trong db
                nguoiDungDAO.deleteNguoiDungById(lsNguoiDung.get(viewType).getUserName());
                //b2- xoa trong list
                NguoiDung nguoiDung = lsNguoiDung.get(viewType);
                lsNguoiDung.remove(nguoiDung);
                //b3. refresh
                notifyDataSetChanged();
            }
        });

        return viewHolder;
    }
    //2.ham gan du lieu
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        NguoiDung nguoiDung = lsNguoiDung.get(position);//lay tu list
        //dua du lieu vao tung thanh phan
        holder.tvName.setText(nguoiDung.getUserName());
        holder.tvPhone.setText(nguoiDung.getPhone());
        //xu ly su kien sua
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //xu ly sua
                Context c = view.getContext();
                Intent intent = new Intent(c, NguoiDungActivity.class);
                //B1- lay du lieu o form cu va day len form moi
                Bundle bundle = new Bundle();
                bundle.putString("userName_key",lsNguoiDung.get(position).getUserName());
                bundle.putString("password_key",lsNguoiDung.get(position).getPassword());
                bundle.putString("phone_key",lsNguoiDung.get(position).getPhone());
                bundle.putString("hoTen_key",lsNguoiDung.get(position).getHoTen());
                intent.putExtra("bun",bundle);
                //B2 - dung intent chuyen
                c.startActivity(intent);

            }
        });
    }
    //tinh tong so item
    @Override
    public int getItemCount() {
        return lsNguoiDung.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder{
        ImageView ivIcon;
        TextView tvName;
        TextView tvPhone;
        ImageView ivDelete;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
