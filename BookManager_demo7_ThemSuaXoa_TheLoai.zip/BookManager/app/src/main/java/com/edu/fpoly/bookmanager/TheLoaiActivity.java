package com.edu.fpoly.bookmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.edu.fpoly.bookmanager.dao.TheLoaiDAO;
import com.edu.fpoly.bookmanager.model.TheLoai;

public class TheLoaiActivity extends AppCompatActivity {
    EditText edMaTheLoai,edTenTheLoai,edMoTa,edViTri;
    Button btnAdd, btnCancel, btnShow;
    TheLoaiDAO theLoaiDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("The Loai");
        setContentView(R.layout.activity_the_loai);
        edMaTheLoai = findViewById(R.id.edMaTheLoai);
        edTenTheLoai = findViewById(R.id.edTenTheLoai);
        edMoTa = findViewById(R.id.edMoTa);
        edViTri = findViewById(R.id.edViTri);
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        if(b!=null)
        {
            edMaTheLoai.setText(b.getString("maTheLoai"));
            edTenTheLoai.setText(b.getString("tenTheLoai"));
            edMoTa.setText(b.getString("moTa"));
            edViTri.setText(b.getString("viTri"));
        }
    }

    public void addTheLoai(View view) {
        theLoaiDAO = new TheLoaiDAO(TheLoaiActivity.this);
        try {
            if(validation()<0)
            {
                Toast.makeText(getApplicationContext(),"Vui long nhap du thong tin",
                        Toast.LENGTH_LONG).show();
            }
            else
            {
                TheLoai theLoai = new TheLoai(edMaTheLoai.getText().toString(),
                        edTenTheLoai.getText().toString(),
                        edMoTa.getText().toString(),
                        Integer.parseInt(edViTri.getText().toString()));
                if(theLoaiDAO.insertTheLoai(theLoai)>0)
                {
                    Toast.makeText(getApplicationContext(),"Them thanh cong",
                            Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Them that bai",
                            Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int validation() {
        int check = 1;
        if(edMaTheLoai.getText().length()==0||
        edTenTheLoai.getText().length()==0||
        edViTri.getText().length()==0||
        edMoTa.getText().length()==0)
        {
            return -1;
        }
        return check;
    }

    public void showTheLoai(View view) {
        finish();
    }
}
