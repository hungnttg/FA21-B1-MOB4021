package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.TheLoai;

import java.util.ArrayList;
import java.util.List;

public class TheLoaiDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "TheLoai";
    public static final String SQL_THE_LOAI = "Create table TheLoai (maTheLoai text primary key, " +
            " tenTheLoai text, moTa text, viTri int);";
    public TheLoaiDAO(Context context)
    {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    //insert
    public int insertTheLoai(TheLoai theLoai)
    {
        ContentValues values = new ContentValues();
        values.put("maTheLoai",theLoai.getMaTheLoai());
        values.put("tenTheLoai",theLoai.getTenTheLoai());
        values.put("moTa",theLoai.getMoTa());
        values.put("viTri",theLoai.getViTri());
        if(checkPrimaryKey(theLoai.getMaTheLoai()))
        {
            int kq = db.update(TABLE_NAME,values,"maTheLoai=?",
                    new String[]{theLoai.getMaTheLoai()});
            if(kq==0)
            {
                return -1;//that bai
            }
            else
            {
                try {
                    if(db.insert(TABLE_NAME,null,values)<=0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 1;
                    }
                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }
        return 1;//thanh cong
    }
    //select all
    public List<TheLoai> getAllTheLoai()
    {
        List<TheLoai> dsTheLoai = new ArrayList<>();
        Cursor c = db.query(TABLE_NAME,null,null,null,null,null,null);
        c.moveToFirst();
        while (c.isAfterLast()==false)
        {
            TheLoai t= new TheLoai();
            t.setMaTheLoai(c.getString(0));
            t.setTenTheLoai(c.getColumnName(1));
            t.setMoTa(c.getString(2));
            t.setViTri(c.getInt(3));
            dsTheLoai.add(t);
            c.moveToNext();
        }
        c.close();
        return dsTheLoai;
    }
    //update
    public int updateTheLoai(TheLoai theLoai)
    {
        ContentValues values = new ContentValues();
        values.put("maTheLoai",theLoai.getMaTheLoai());
        values.put("tenTheLoai",theLoai.getTenTheLoai());
        values.put("moTa",theLoai.getMoTa());
        values.put("viTri",theLoai.getViTri());
        int kq = db.update(TABLE_NAME,values,"maTheLoai=?",
                new String[]{theLoai.getMaTheLoai()});
        if(kq<=0)
        {
            return -1;
        }
        return 1;
    }
    //delete
    public int deleteTheLoaiByID(String ma)
    {
        int kq = db.delete(TABLE_NAME,"maTheLoai=?",
                new String[]{ma});
        if(kq<=0)
        {
            return -1;
        }
        return 1;
    }
    //kiem tra khoa chinh
    public boolean checkPrimaryKey(String str)
    {
        String[] columns = {"maTheLoai"};
        String selection = "maTheLoai=?";
        String[] selectionArgs = {str};
        Cursor c = null;
        try {
            c =db.query(TABLE_NAME,columns,selection,selectionArgs,null,null,null);
            c.moveToFirst();
            int i = c.getCount();
            c.close();
            if(i<=0){
                return false;
            }
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
