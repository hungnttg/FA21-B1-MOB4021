package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class NguoiDungDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "NguoiDung";
    public static final String SQL_NGUOI_DUNG = "CREATE TABLE NguoiDung(userName text PRIMARY KEY," +
            "password text,phone text,hoTen text);";

    public NguoiDungDAO(Context context)
    {
        dbHelper = new DatabaseHelper(context);//thực thi tạo CSDL và bảng dữ liệu
        db = dbHelper.getWritableDatabase();//cho phép ghi dữ liệu vào CSDL
    }
    //viet cac ham
    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values = new ContentValues();//tạo bộ chứa dư liệu
        //đưa dữ liệu từ đối tượng nd vào bộ chứa
        values.put("userName",nd.getUserName());
        values.put("password",nd.getPassword());
        values.put("phone",nd.getPhone());
        values.put("hoTen",nd.getHoTen());
        //thực thi insert dữ liệu
        try {
            if(db.insert(TABLE_NAME,null,values)==-1)
            {
                return -1;//insert that bai
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return 1;//insert thanh cong
    }
    //ham doc du lieu len listview
    public List<NguoiDung> getAllNguoiDung()
    {
        List<NguoiDung> list = new ArrayList<>();//tao danh sach chua nguoi dung
        //Tao con tro
        Cursor c = db.query(TABLE_NAME,
                null,null,null,null,null,null);
        //di chuyen ve ban ghi dau tiem
        c.moveToFirst();
        while (!c.isAfterLast())//neu khong phai ban ghi cuoi cung
        {
            NguoiDung n = new NguoiDung();//tao doi tuong chua du lueu
            //gan du lieu doc duoc tu database vaof doi tuong
            n.setUserName(c.getString(0));
            n.setPassword(c.getString(1));
            n.setPhone(c.getString(2));
            n.setHoTen(c.getString(3));
            //dua doi tuong vao list
            list.add(n);
            //di chuyen sang ban ghi tiep theo
            c.moveToNext();
        }
        c.close();
        return list;
    }
    //xoa
    public int deleteNguoiDungById(String userName)
    {
        int kq = db.delete(TABLE_NAME,"userName=?",
                new String[]{userName});
        if(kq<=0)
            return -1;//khong thanh cong
        return 1;//thanh cong
    }
    //sua
    public int updateNguoiDung(NguoiDung nguoiDung)
    {
        ContentValues values = new ContentValues();
        values.put("phone",nguoiDung.getPhone());
        values.put("hoTen",nguoiDung.getHoTen());
        int kq = db.update(TABLE_NAME,values,"userName=?",
                new String[]{nguoiDung.getUserName()});
        if(kq<=0)
            return -1;//khong thanh cong
        return 1;//thanh cong
    }
}
