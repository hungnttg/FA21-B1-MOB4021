package com.edu.fpoly.bookmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

public class NguoiDungActivity extends AppCompatActivity {
    Button btnThemNguoiDung;
    NguoiDungDAO nguoiDungDAO;
    EditText edUser,edPass,edRepass,edPhone,edFullName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nguoi_dung);
        setTitle("Them Nguoi Dung");
        btnThemNguoiDung = (Button)findViewById(R.id.btnAddUser);
        edUser = (EditText)findViewById(R.id.edUserName);
        edPass = (EditText)findViewById(R.id.edPassword);
        edPhone = (EditText)findViewById(R.id.edPhone);
        //edRepass = (EditText)findViewById(R.id.edRePassword);
        edFullName = (EditText)findViewById(R.id.edFullName);
    }


    public void addUser(View view) {
        nguoiDungDAO = new NguoiDungDAO(NguoiDungActivity.this);//goi lop dao
        //Truyen du lieu nguoi dung nhap cho user
        NguoiDung user = new NguoiDung(edUser.getText().toString(),edPass.getText().toString(),
                edPhone.getText().toString(),edFullName.getText().toString());
        try {
            if(nguoiDungDAO.insertNguoiDung(user)>0)
            {
                Toast.makeText(getApplicationContext(),"Them thanh cong",
                        Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Them that bai",
                Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
