package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

public class NguoiDungDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "NguoiDung";
    public static final String SQL_NGUOI_DUNG="CREATE TABLE NguoiDung ( " +
            "userName text PRIMARY KEY, password text, phone text, hoTen text);";
    public NguoiDungDAO(Context context)
    {
        dbHelper = new DatabaseHelper(context);//goi ham tao csdl va bang du lieu
        db = dbHelper.getWritableDatabase();//cho phep ghi du lieu vao database
    }
    //viet cac ham
    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values = new ContentValues();
        values.put("userName",nd.getUserName());
        values.put("password",nd.getPassword());
        values.put("phone",nd.getPhone());
        values.put("hoTen",nd.getHoTen());
        try {
            if(db.insert(TABLE_NAME,null,values)==-1)
            {
                return -1;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return 1;
    }
}
