package com.edu.fpoly.bookmanager.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.edu.fpoly.bookmanager.R;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.List;

public class NguoiDungAdapter extends BaseAdapter {
    List<NguoiDung> lsNguoiDung;//mang
    Context context;//ngu canh
    LayoutInflater inflater;//doi tuong tao layout
    NguoiDungDAO nguoiDungDAO;//xu ly su kien
    //khoi tao
    public NguoiDungAdapter(Context context,List<NguoiDung> lsNguoiDung)
    {
        super();
        this.context = context;
        this.lsNguoiDung = lsNguoiDung;
        this.inflater
                =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //tong so item
    @Override
    public int getCount() {
        return lsNguoiDung.size();
    }
    //lay ve chi tiet 1 item
    @Override
    public Object getItem(int i) {
        return lsNguoiDung.get(i);
    }
    //lay id cua item
    @Override
    public long getItemId(int i) {
        return 0;
    }
    //ham tao view (1.Tao layout + 2. Gan du lieu cho layout)
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view==null)//nếu chưa có view thì tạo view mới
        {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.item_nguoi_dung,null);//tao layout
            //anh xa tung thanh phan
            holder.img = (ImageView)view.findViewById(R.id.ivIcon);
            holder.txtName = (TextView)view.findViewById(R.id.tvName);
            holder.txtPhone = (TextView)view.findViewById(R.id.tvPhone);
            holder.imgDelete = (ImageView)view.findViewById(R.id.ivDelete);
            //xu ly su kien
            holder.imgDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            //tao template de lan sau su dung
            view.setTag(holder);
        }
        else //nếu có view rồi, lấy view cũ ra sử dụng
        {
            holder = (ViewHolder)view.getTag();
        }
        //set du lieu
        NguoiDung nd = (NguoiDung)lsNguoiDung.get(i);
        holder.txtName.setText(nd.getHoTen());
        holder.txtPhone.setText(nd.getPhone());
        return view;
    }
    public static class ViewHolder {
        ImageView img;
        TextView txtName;
        TextView txtPhone;
        ImageView imgDelete;
    }
}
