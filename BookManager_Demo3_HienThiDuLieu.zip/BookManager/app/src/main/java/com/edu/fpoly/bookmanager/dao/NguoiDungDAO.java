package com.edu.fpoly.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.edu.fpoly.bookmanager.database.DatabaseHelper;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class NguoiDungDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;
    public static final String TABLE_NAME = "NguoiDung";
    public static final String SQL_NGUOI_DUNG = "CREATE TABLE NguoiDung(userName text PRIMARY KEY," +
            "password text,phone text,hoTen text);";

    public NguoiDungDAO(Context context)
    {
        dbHelper = new DatabaseHelper(context);//thực thi tạo CSDL và bảng dữ liệu
        db = dbHelper.getWritableDatabase();//cho phép ghi dữ liệu vào CSDL
    }
    //viet cac ham
    public int insertNguoiDung(NguoiDung nd)
    {
        ContentValues values = new ContentValues();//tạo bộ chứa dư liệu
        //đưa dữ liệu từ đối tượng nd vào bộ chứa
        values.put("userName",nd.getUserName());
        values.put("password",nd.getPassword());
        values.put("phone",nd.getPhone());
        values.put("hoTen",nd.getHoTen());
        //thực thi insert dữ liệu
        try {
            if(db.insert(TABLE_NAME,null,values)==-1)
            {
                return -1;//insert that bai
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return 1;//insert thanh cong
    }
    //ham hien thi du lieu
    public List<NguoiDung> getAllNguoiDung()
    {
        List<NguoiDung> lsNguoiDung = new ArrayList<>();//danh sach chus du lieu
        //con tro doc du lieu tu bang
        Cursor c = db.query(TABLE_NAME,null,null,
                null,null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (c.isAfterLast()==false)//neu khong phai ban ghi cuoi cung
        {
            NguoiDung nd = new NguoiDung();//tao doi tuong chua du lieu doc duoc tu con tro
            nd.setUserName(c.getString(0));
            nd.setPassword(c.getString(1));
            nd.setPhone(c.getString(2));
            nd.setHoTen(c.getString(3));
            lsNguoiDung.add(nd);//dua doi tuong nd vao danh sach
            c.moveToNext();//chuyen sang ban ghi tiep theo de doc
        }
        c.close();
        return lsNguoiDung;
    }
}
