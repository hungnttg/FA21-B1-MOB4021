package com.edu.fpoly.bookmanager.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edu.fpoly.bookmanager.NguoiDungActivity;
import com.edu.fpoly.bookmanager.R;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.List;

public class NguoiDungAdapterRecycler extends
RecyclerView.Adapter<NguoiDungAdapterRecycler.RecyclerViewHolder> {
    private Context context;
    private List<NguoiDung> arrNguoiDung;
    private LayoutInflater inflater;
    NguoiDungDAO nguoiDungDAO;

    public NguoiDungAdapterRecycler(Context context, List<NguoiDung> arrNguoiDung) {
        this.context = context;
        this.arrNguoiDung = arrNguoiDung;
        nguoiDungDAO = new NguoiDungDAO(context);
        this.inflater =
                (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //ham tao view
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_nguoi_dung,null);
        RecyclerViewHolder viewHolder = new RecyclerViewHolder(view);
        viewHolder.ivIcon = view.findViewById(R.id.ivIcon);
        viewHolder.tvName = view.findViewById(R.id.tvName);
        viewHolder.tvPhone = view.findViewById(R.id.tvPhone);
        viewHolder.ivDelete = view.findViewById(R.id.ivDelete);
        viewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //xu ly xoa
                nguoiDungDAO.deleteNguoiDungByID(arrNguoiDung.get(viewType).getUserName());
                NguoiDung nguoiDung = arrNguoiDung.get(viewType);
                arrNguoiDung.remove(nguoiDung);
                notifyDataSetChanged();
            }
        });
        return viewHolder;
    }
    //ham gan du lieu
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        NguoiDung nguoiDung = arrNguoiDung.get(position);
        holder.tvName.setText(nguoiDung.getUserName());
        holder.tvPhone.setText(nguoiDung.getPhone());
        //xu ly su kien
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //xu ly sua du lieu
                Context context = view.getContext();//lay ve context
                //chuyen du lieu len form de sua
                Intent intent = new Intent(context, NguoiDungActivity.class);
                //
                Bundle bundle = new Bundle();
                bundle.putString("userName_key",arrNguoiDung.get(position).getUserName());
                bundle.putString("password_key",arrNguoiDung.get(position).getPassword());
                bundle.putString("phone_key",arrNguoiDung.get(position).getPhone());
                bundle.putString("hoTen_key",arrNguoiDung.get(position).getHoTen());
                //
                intent.putExtra("bun",bundle);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrNguoiDung.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder{
        ImageView ivIcon;
        TextView tvName;
        TextView tvPhone;
        ImageView ivDelete;
        public RecyclerViewHolder(View itemView) {
            super(itemView);
            this.ivIcon = ivIcon;
            this.tvName = tvName;
            this.tvPhone = tvPhone;
            this.ivDelete = ivDelete;
        }
    }
}
