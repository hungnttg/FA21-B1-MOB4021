package com.edu.fpoly.bookmanager;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.edu.fpoly.bookmanager.adapter.NguoiDungAdapter;
import com.edu.fpoly.bookmanager.adapter.NguoiDungAdapterRecycler;
import com.edu.fpoly.bookmanager.dao.NguoiDungDAO;
import com.edu.fpoly.bookmanager.model.NguoiDung;

import java.util.ArrayList;
import java.util.List;

public class ListNguoiDungActivity extends AppCompatActivity {
    Intent intent;
    public List<NguoiDung> lsNguoiDung = new ArrayList<>();
    ListView listViewND;
    RecyclerView recyclerView;
    NguoiDungDAO nguoiDungDAO;
    NguoiDungAdapter adapter = null;
    NguoiDungAdapterRecycler adapterRecycler=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nguoi_dung);
        //listViewND = findViewById(R.id.lvNguoiDung);
        recyclerView = findViewById(R.id.recyclerviewND);
        nguoiDungDAO = new NguoiDungDAO(ListNguoiDungActivity.this);
        lsNguoiDung = nguoiDungDAO.getAllNguoiDung();
        //adapter = new NguoiDungAdapter(this,lsNguoiDung);
        //listViewND.setAdapter(adapter);
        adapterRecycler = new NguoiDungAdapterRecycler(this,lsNguoiDung);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapterRecycler);

    }

    public void startThemNguoiDung(View view)
    {
        intent = new Intent(ListNguoiDungActivity.this,NguoiDungActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()) {
            case R.id.add:
               // intent = new Intent(ListNguoiDungActivity.this,NguoiDungActivity.class);
               // startActivity(intent);
                return(true);
            case R.id.changePass:
                break;
            case R.id.logOut:

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        lsNguoiDung = nguoiDungDAO.getAllNguoiDung();
        adapterRecycler = new NguoiDungAdapterRecycler(this,lsNguoiDung);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapterRecycler);
    }
}
